#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.6.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Tue Sep  8 17:45:32 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_VehicleBPTable_type.BP_STRUCT_VehicleBPTable_type
// 0x0040
struct FBP_STRUCT_VehicleBPTable_type
{
	int                                                ID_0_0D9DF74051BBD583279703B701F172E4;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     Path_2_2F72974026FE3BC32110651501735958;                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     CName_3_138BC5001BE2FE5E5E66B36807255925;                 // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                VehicleShapeID_4_2C43E38070C85DC025E56CC303F69884;        // 0x0028(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x4];                                       // 0x002C(0x0004) MISSED OFFSET
	struct FString                                     LobbyPath_5_4594B5404A7DACE145FA22A607895AE8;             // 0x0030(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

