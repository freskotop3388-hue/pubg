#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.6.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Tue Sep  8 17:45:29 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Classes
//---------------------By 建锅 @JGNB_K---------------------------

// AnimBlueprintGeneratedClass CH_ABP_Parachute.CH_ABP_Parachute_C
// 0x1718 (0x2FC8 - 0x18B0)
class UCH_ABP_Parachute_C : public UAnimInstanceParachute
{
public:
	struct FPointerToUberGraphFrame                    UberGraphFrame;                                           // 0x18B0(0x0008) (Transient, DuplicateTransient)
	struct FAnimNode_Root                              AnimGraphNode_Root_5905DDEE44E1052B513EE690B4F57742;      // 0x18B8(0x0050)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_80DFA2864DFC581215F60B95F7DC9380;// 0x1908(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_8E329B0A47E416418324F99CE29A2401;// 0x1950(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_B50C1AE84D9436FFBC33709F6F0EB106;// 0x1998(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_FD5B9C494EBA47F8974327B3D99915E2;// 0x19E0(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_A39C00F94B8B17F3DF23A99C3DDB2E88;// 0x1A28(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_70C75196485F1D5760DEEA95ED192B22;// 0x1A70(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_4A2747AE48EAD59BF53D288CCDE102BD;// 0x1AB8(0x0048)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_693DD741490FB5D23D825FBDF1CAF303;// 0x1B00(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_04DFCD6146926108DD38F59F6296BDC1;// 0x1B70(0x0050)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_D3DD31C0472B6C0F4726D7BCD13BE4FD;// 0x1BC0(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_32A4049D45BACC2F0CF64A83AC96F015;// 0x1C30(0x0050)
	struct FAnimNode_SyncBlendSpacePlayerSafety        AnimGraphNode_SyncBlendSpacePlayerSafety_23C71D0842200B0BB48F7F89E4304980;// 0x1C80(0x0168)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_61EF6894468110B4D589E1B7009DAEEA;// 0x1DE8(0x00D0)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_FD44ACE0489529B1B1E3468593ABF6EC;// 0x1EB8(0x0070)
	struct FAnimNode_ApplyAdditive                     AnimGraphNode_ApplyAdditive_3C4F258E4B055030C88841AC216C055E;// 0x1F28(0x0080)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_F246D3BC43638C1E4A0CD7A4093ECFE3;// 0x1FA8(0x00D0)
	struct FAnimNode_Slot                              AnimGraphNode_Slot_61E0CF97485E1F3792FC1AA15BF9199A;      // 0x2078(0x0070)
	struct FAnimNode_ConvertComponentToLocalSpace      AnimGraphNode_ComponentToLocalSpace_6D8F6D4B44582CFC42357EA838EF8EBA;// 0x20E8(0x0050)
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_41FE3C53498375A67AA95F8E978689DD;// 0x2138(0x00C0)
	struct FAnimNode_ConvertLocalToComponentSpace      AnimGraphNode_LocalToComponentSpace_6F58BAA54B219C34FE70588BF70586AC;// 0x21F8(0x0050)
	struct FAnimNode_ModifyBone                        AnimGraphNode_ModifyBone_CED299CA481478CB316239B95C32C8B6;// 0x2248(0x00C0)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_BB16DD9C48109CFD1788B3B60A435C67;// 0x2308(0x00D0)
	struct FAnimNode_BlendSpacePlayer                  AnimGraphNode_BlendSpacePlayer_EC7772CA4717595422791DB0356E7446;// 0x23D8(0x0128)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_99288328421057D37BB1198AA773CFA8;// 0x2500(0x00D0)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_E61FA9B94E955F50CF334983A7D033E8;// 0x25D0(0x0050)
	struct FAnimNode_BlendSpacePlayer                  AnimGraphNode_BlendSpacePlayer_326A87BA48D64DA8E0BC20B8D64A8B2D;// 0x2620(0x0128)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_3DD95A6A4389DA801A52ADA435C84617;// 0x2748(0x0050)
	struct FAnimNode_StateMachine                      AnimGraphNode_StateMachine_5EEF16B74E309FB91AA894B9DC6DDF46;// 0x2798(0x00D8)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_B53A6CA547FE1C98AF198C8EA998D46A;// 0x2870(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_9326BBEB4B42336572D0429EE91307E5;// 0x28B8(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_B4DC46DC4A69BEE6420B65B133C2DA7D;// 0x2900(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_EF558E8C47A2D32F0AA02E9DC166B80B;// 0x2948(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_BD7572964E901FCB78C8ADA9BFA6FB05;// 0x2990(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_F1D98C164D1DA7E269F82B99AA85A3C0;// 0x29D8(0x0048)
	struct FAnimNode_TransitionResult                  AnimGraphNode_TransitionResult_320BE4BD4FA38ED2E9247FBA473D5E69;// 0x2A20(0x0048)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_99D9907646EC8278473B61B0AAA2D6F9;// 0x2A68(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_DEBF347949FB4C8F8FFEE7B54833181A;// 0x2AD8(0x0050)
	struct FAnimNode_SequenceEvaluator                 AnimGraphNode_SequenceEvaluator_020889A2426931D7C123DA9D3B491177;// 0x2B28(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_6A26C8704A354B084C446599EB406BA7;// 0x2B98(0x0050)
	struct FAnimNode_SequencePlayer                    AnimGraphNode_SequencePlayer_7004288B4C09A7CC124BB0BE9F26874B;// 0x2BE8(0x0070)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_410219AF4889F4C4FAC21AB8B18D0DC0;// 0x2C58(0x0050)
	struct FAnimNode_BlendSpacePlayer                  AnimGraphNode_BlendSpacePlayer_7F58C2804CD31C02288F4B81263A22FF;// 0x2CA8(0x0128)
	struct FAnimNode_Root                              AnimGraphNode_StateResult_545521154549F6BA8135258C04516FE4;// 0x2DD0(0x0050)
	struct FAnimNode_StateMachine                      AnimGraphNode_StateMachine_2BB5E32F47F76CEED39FADB0C583A611;// 0x2E20(0x00D8)
	struct FAnimNode_BlendListByBool                   AnimGraphNode_BlendListByBool_8A5819BC46CE926E4F3D8EB521DF5E1A;// 0x2EF8(0x00D0)

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("AnimBlueprintGeneratedClass CH_ABP_Parachute.CH_ABP_Parachute_C");
		return pStaticClass;
	}


	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_BlendListByBool_61EF6894468110B4D589E1B7009DAEEA();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_SequencePlayer_FD44ACE0489529B1B1E3468593ABF6EC();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_BlendListByBool_F246D3BC43638C1E4A0CD7A4093ECFE3();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_BlendListByBool_BB16DD9C48109CFD1788B3B60A435C67();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_BlendSpacePlayer_EC7772CA4717595422791DB0356E7446();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_BlendListByBool_99288328421057D37BB1198AA773CFA8();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_SequencePlayer_D3DD31C0472B6C0F4726D7BCD13BE4FD();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_SequencePlayer_693DD741490FB5D23D825FBDF1CAF303();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_TransitionResult_4A2747AE48EAD59BF53D288CCDE102BD();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_TransitionResult_70C75196485F1D5760DEEA95ED192B22();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_SyncBlendSpacePlayerSafety_23C71D0842200B0BB48F7F89E4304980();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_TransitionResult_A39C00F94B8B17F3DF23A99C3DDB2E88();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_BlendSpacePlayer_326A87BA48D64DA8E0BC20B8D64A8B2D();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_TransitionResult_B53A6CA547FE1C98AF198C8EA998D46A();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_TransitionResult_FD5B9C494EBA47F8974327B3D99915E2();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_TransitionResult_9326BBEB4B42336572D0429EE91307E5();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_TransitionResult_B4DC46DC4A69BEE6420B65B133C2DA7D();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_TransitionResult_EF558E8C47A2D32F0AA02E9DC166B80B();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_TransitionResult_B50C1AE84D9436FFBC33709F6F0EB106();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_TransitionResult_BD7572964E901FCB78C8ADA9BFA6FB05();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_TransitionResult_F1D98C164D1DA7E269F82B99AA85A3C0();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_TransitionResult_320BE4BD4FA38ED2E9247FBA473D5E69();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_SequenceEvaluator_020889A2426931D7C123DA9D3B491177();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_TransitionResult_8E329B0A47E416418324F99CE29A2401();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_BlendSpacePlayer_7F58C2804CD31C02288F4B81263A22FF();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_TransitionResult_80DFA2864DFC581215F60B95F7DC9380();
	void EvaluateGraphExposedInputs_ExecuteUbergraph_CH_ABP_Parachute_AnimGraphNode_BlendListByBool_8A5819BC46CE926E4F3D8EB521DF5E1A();
	void ExecuteUbergraph_CH_ABP_Parachute(int EntryPoint);
};


}

