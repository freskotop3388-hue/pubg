#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.6.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Tue Sep  8 17:45:35 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_StatEventType_type.BP_STRUCT_StatEventType_type
// 0x0014
struct FBP_STRUCT_StatEventType_type
{
	struct FString                                     DisplayName_0_7D516B402CBFB7AB2A776EB00D8D1405;           // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                id_1_49A788C0256E4AF90B9DAE5205E4F254;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

