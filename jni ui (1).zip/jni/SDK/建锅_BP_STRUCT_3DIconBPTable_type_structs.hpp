#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.6.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Tue Sep  8 17:45:35 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_3DIconBPTable_type.BP_STRUCT_3DIconBPTable_type
// 0x0028
struct FBP_STRUCT_3DIconBPTable_type
{
	struct FString                                     CName_0_197F95006C7D41D02E19833803105905;                 // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_6249C74062AE6BD53F17F69101F33054;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     Path_2_064E67406FC200F32023304A0331E958;                  // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

