#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.6.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Tue Sep  8 17:45:30 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_TransColumns_type.BP_STRUCT_TransColumns_type
// 0x0020
struct FBP_STRUCT_TransColumns_type
{
	struct FString                                     Columns_0_47AC24714CA709ABE62AB2B97B02C861;               // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Table_1_B0FEB2B8486D4078687135A2F1589ADF;                 // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

