#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.6.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Tue Sep  8 17:45:33 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_GameModeBPTable_type.BP_STRUCT_GameModeBPTable_type
// 0x0028
struct FBP_STRUCT_GameModeBPTable_type
{
	int                                                ID_0_5A5311F84AF5AD63F284598DF413D62D;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     CName_1_120D6DB74537DE28D87E4BAD2052E558;                 // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Path_2_D808EF6946A66B7E51F6318FC7CCE098;                  // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

