#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.6.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Tue Sep  8 17:45:36 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_Client120FPSMapping_type.BP_STRUCT_Client120FPSMapping_type
// 0x0038
struct FBP_STRUCT_Client120FPSMapping_type
{
	int                                                ID_0_52B7B2807016C5CE506644460AB41F74;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0004(0x0004) MISSED OFFSET
	struct FString                                     ModelNames_1_399D08807AD6F26037FD5FE60034ECE3;            // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     RecommendFPS_2_1A6DF000025FF64C17E158AF0DA5B963;          // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     MaxFPSByQuality_3_6AD77C001F8707C23E3E50050F416079;       // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

