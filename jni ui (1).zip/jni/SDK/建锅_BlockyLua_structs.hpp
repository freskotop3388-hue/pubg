#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.6.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Tue Sep  8 17:45:13 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Enums
//---------------------By 建锅 @JGNB_K---------------------------

// Enum BlockyLua.EBlockyEditorShortcutKey
enum class EBlockyEditorShortcutKey : uint8_t
{
	EBlockyEditorShortcutKey__None = 0,
	EBlockyEditorShortcutKey__Clone = 1,
	EBlockyEditorShortcutKey__Copy = 2,
	EBlockyEditorShortcutKey__Cut  = 3,
	EBlockyEditorShortcutKey__Paste = 4,
	EBlockyEditorShortcutKey__Undo = 5,
	EBlockyEditorShortcutKey__Redo = 6,
	EBlockyEditorShortcutKey__Delete = 7,
	EBlockyEditorShortcutKey__Search = 8,
	EBlockyEditorShortcutKey__Save = 9,
	EBlockyEditorShortcutKey__Log  = 10,
	EBlockyEditorShortcutKey__Escape = 11,
	EBlockyEditorShortcutKey__EBlockyEditorShortcutKey_MAX = 12
};


// Enum BlockyLua.ESearchResultVisibleType
enum class ESearchResultVisibleType : uint8_t
{
	ESearchResultVisibleType__SRVT_ShowAll = 0,
	ESearchResultVisibleType__SRVT_OnlyBlocks = 1,
	ESearchResultVisibleType__SRVT_OnlyGraphs = 2,
	ESearchResultVisibleType__SRVT_OnlyPresets = 3,
	ESearchResultVisibleType__SRVT_MAX = 4
};


// Enum BlockyLua.BLOCKYLUA_AUTO_SCROLL_TYPE
enum class EBLOCKYLUA_AUTO_SCROLL_TYPE : uint8_t
{
	BLOCKYLUA_AUTO_SCROLL_TYPE__LEFT_RIGHT = 0,
	BLOCKYLUA_AUTO_SCROLL_TYPE__PING_PONG = 1,
	BLOCKYLUA_AUTO_SCROLL_TYPE__BLOCKYLUA_AUTO_SCROLL_MAX = 2
};



//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// ScriptStruct BlockyLua.IntArrayWrapper
// 0x0010
struct FIntArrayWrapper
{
	TArray<int>                                        Values;                                                   // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

// ScriptStruct BlockyLua.SlotData
// 0x0020
struct FSlotData
{
	class UBlockBase*                                  LinkedSlotHost;                                           // 0x0000(0x0008) (ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x18];                                      // 0x0008(0x0018) MISSED OFFSET
};

}

