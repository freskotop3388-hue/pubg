#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.6.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Tue Sep  8 17:45:39 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_ResourcePatchCfg_type.BP_STRUCT_ResourcePatchCfg_type
// 0x0020
struct FBP_STRUCT_ResourcePatchCfg_type
{
	struct FString                                     Res_0_5336A20017C3AD3C6DD6CA9604AB86B3;                   // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Version_1_77115100133C471835D454DB02BD35DE;               // 0x0010(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

