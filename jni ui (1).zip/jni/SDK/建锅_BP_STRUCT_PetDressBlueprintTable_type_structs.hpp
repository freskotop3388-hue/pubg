#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.6.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Tue Sep  8 17:45:33 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_PetDressBlueprintTable_type.BP_STRUCT_PetDressBlueprintTable_type
// 0x0028
struct FBP_STRUCT_PetDressBlueprintTable_type
{
	int                                                Slot_0_31125FC006688BBB2E6646B20FAFCD34;                  // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                ID_1_688F3A8033A7814C565560B30E5FAEF4;                    // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     Path_2_51589A804E9002622E9485530FAF46F8;                  // 0x0008(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     LobbyPath_3_7916988003DE45F8216AD7E90D649918;             // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

