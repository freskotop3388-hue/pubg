#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.6.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Tue Sep  8 17:45:38 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_GlobalMenuSwitchTable_type.BP_STRUCT_GlobalMenuSwitchTable_type
// 0x0008
struct FBP_STRUCT_GlobalMenuSwitchTable_type
{
	int                                                ID_0_14E478C009E418DF06E7F5440259BAA4;                    // 0x0000(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                Open_1_4FBB1A0034F5B7D2525FA9D509BB14EE;                  // 0x0004(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
};

}

