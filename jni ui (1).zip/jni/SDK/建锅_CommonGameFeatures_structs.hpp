#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.6.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Tue Sep  8 17:45:20 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// ScriptStruct CommonGameFeatures.RepControlGroupData
// 0x0050
struct FRepControlGroupData
{
	TMap<int64_t, int>                                 RepControlMap;                                            // 0x0000(0x0050) (ZeroConstructor)
};

}

