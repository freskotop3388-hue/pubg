#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.6.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Tue Sep  8 17:45:33 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_EffectItemBPTable_type.BP_STRUCT_EffectItemBPTable_type
// 0x0038
struct FBP_STRUCT_EffectItemBPTable_type
{
	struct FString                                     CName_0_7A84EC0050230586473C7F7D0FE10665;                 // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                ID_1_77819E4026AAFDFB236ABAEE0425FEA4;                    // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData00[0x4];                                       // 0x0014(0x0004) MISSED OFFSET
	struct FString                                     LobbyPath_2_667FDC4028D32C79798D4B120AC19EB8;             // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	struct FString                                     Path_3_084F3E402A58FF7D0D305BF205FF1C88;                  // 0x0028(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

