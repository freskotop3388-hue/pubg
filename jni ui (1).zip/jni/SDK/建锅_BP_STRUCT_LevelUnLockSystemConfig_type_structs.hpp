#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.6.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Tue Sep  8 17:45:38 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_LevelUnLockSystemConfig_type.BP_STRUCT_LevelUnLockSystemConfig_type
// 0x0028
struct FBP_STRUCT_LevelUnLockSystemConfig_type
{
	struct FString                                     IconPath_3_7C9B52C036EC4BE564B11987066BCFF8;              // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
	int                                                SystemID_4_462B11C04FA0BAF74638CAB20CA227C4;              // 0x0010(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	int                                                SystemName_5_7736CEC05B30C1C15DE54FAB02285C95;            // 0x0014(0x0004) (Edit, BlueprintVisible, ZeroConstructor, IsPlainOldData)
	struct FString                                     CheckFunction_6_22E4F6407D715825528B5EC70961BBFE;         // 0x0018(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

