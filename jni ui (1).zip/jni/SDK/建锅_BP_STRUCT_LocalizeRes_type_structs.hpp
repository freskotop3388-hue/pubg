#pragma once

// SDK集成工具By建锅 - @JGNB_K (4.6.0 -- 64Bit) SDK 工具 By 建锅 @JGNB_K
// Telegram频道:- @JGNB_K
// 此文件生成时间Tue Sep  8 17:45:31 2026
 
namespace SDK
{
//---------------------By 建锅 @JGNB_K---------------------------
//Script Structs
//---------------------By 建锅 @JGNB_K---------------------------

// UserDefinedStruct BP_STRUCT_LocalizeRes_type.BP_STRUCT_LocalizeRes_type
// 0x0010
struct FBP_STRUCT_LocalizeRes_type
{
	struct FString                                     TextValue_0_4D37165A410D67320AF278A1C1028E4F;             // 0x0000(0x0010) (Edit, BlueprintVisible, ZeroConstructor)
};

}

