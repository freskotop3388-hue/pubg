#pragma once
//@xvaLuex -- t.me/UltimateEngine 

namespace Menu
{
    void ImAim(int x, int y)
    {

    }
    void Render()
    {
    }
}